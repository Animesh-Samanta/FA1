package test;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import application.Booking;
import application.Trainee;
import application.Validator;

public class ValidationTest {
	@Rule
	public ExpectedException ee=ExpectedException.none();
	@Test
	public void isValidBatchName() {
		Validator valid=new Validator();
		
		Assert.assertTrue(valid.isValidBatchName("JEE-RT1-CS"));
	
	}
    @Test
	public void isValidCourseName() {
Validator valid=new Validator();
		
		Assert.assertTrue(valid.isValidCourseName("FA1"));
		
	}
	@Test
	public void isValidAssessmentDate() {
Validator valid=new Validator();
		
		Assert.assertTrue(valid.isValidAssessmentDate(LocalDate.now().plusDays(4)));
		
	}

	@Test
	public void isValidAssessmentType() {
Validator valid=new Validator();
		
		Assert.assertTrue(valid.isValidAssessmentType("Objective"));
		
		
	}
@Test
	public void isValidEmailId() {
		Booking booking=new Booking();
		booking.setAssessmentDate(LocalDate.now().plusDays(4));
		booking.setAssessmentType("Objective");
		booking.setBatchName("JEE-RT1-CS");		
		booking.setCourseName("FA1");
		
		Trainee trainee1 = new Trainee();
		trainee1.setEmpNo(626262);
		trainee1.setEmailId("John_626262");
		
		List<Trainee>tlist = new ArrayList<Trainee>();
		tlist.add(trainee1);
		booking.setTraineesList(tlist);
		Validator valid=new Validator();
		Assert.assertTrue(valid.isValidEmailId(tlist));
	}
	
	
	
	@Test
	public void isInvalidValidBatchName() {
		Validator valid=new Validator();
		
		Assert.assertFalse(valid.isValidBatchName("JEE-rt1-cs"));
		Assert.assertFalse(valid.isValidBatchName("JEErt1cs"));
	}
    @Test
	public void isInvalidValidCourseName() {
Validator valid=new Validator();
		
		Assert.assertFalse(valid.isValidCourseName("fa6"));
		
	}
	@Test
	public void isInvalidValidAssessmentDate() {
Validator valid=new Validator();
		
		Assert.assertFalse(valid.isValidAssessmentDate(LocalDate.now().plusDays(8)));
		
	}

	@Test
	public void isInvalidValidAssessmentType() {
Validator valid=new Validator();
		
		Assert.assertFalse(valid.isValidAssessmentType("Obj"));
		
		
	}
@Test
	public void isInvalidValidEmailId() {
		Booking booking=new Booking();
		booking.setAssessmentDate(LocalDate.now().plusDays(4));
		booking.setAssessmentType("Objective");
		booking.setBatchName("JEE-RT1-CS");		
		booking.setCourseName("FA1");
		
		Trainee trainee1 = new Trainee();
		trainee1.setEmpNo(626262);
		trainee1.setEmailId("John_262626");
		
		List<Trainee>tlist = new ArrayList<Trainee>();
		tlist.add(trainee1);
		booking.setTraineesList(tlist);
		Validator valid=new Validator();
		Assert.assertFalse(valid.isValidEmailId(tlist));
	}
@Test
public void isInvalidExceptionValidBatchName() throws Exception {
	Booking booking=new Booking();
	booking.setAssessmentDate(LocalDate.now().plusDays(4));
	booking.setAssessmentType("Objective");
	booking.setBatchName("JEE-rt1-cs");		
	booking.setCourseName("FA1");
	
	Trainee trainee1 = new Trainee();
	trainee1.setEmpNo(626262);
	trainee1.setEmailId("John_626262");
	
	List<Trainee>tlist = new ArrayList<Trainee>();
	tlist.add(trainee1);
	booking.setTraineesList(tlist);
	ee.expect(Exception.class);
	ee.expectMessage("Validator.INVALID_BATCH_NAME");
	Validator valid=new Validator();
	valid.validate(booking);
	

}
@Test
public void isInvalidExceptionValidCourseName() throws Exception {
	Booking booking=new Booking();
	booking.setAssessmentDate(LocalDate.now().plusDays(4));
	booking.setAssessmentType("Objective");
	booking.setBatchName("JEE-RT1-CS");		
	booking.setCourseName("df");
	
	Trainee trainee1 = new Trainee();
	trainee1.setEmpNo(626262);
	trainee1.setEmailId("John_626262");
	
	List<Trainee>tlist = new ArrayList<Trainee>();
	tlist.add(trainee1);
	booking.setTraineesList(tlist);
	ee.expect(Exception.class);
	ee.expectMessage("Validator.INVALID_COURSE_NAME");
	Validator valid=new Validator();
	valid.validate(booking);
	
}
@Test
public void isInvalidExceptionValidAssessmentDate() throws Exception {
	Booking booking=new Booking();
	booking.setAssessmentDate(LocalDate.now().plusDays(10));
	booking.setAssessmentType("Objective");
	booking.setBatchName("JEE-RT1-CS");		
	booking.setCourseName("FA6");
	
	Trainee trainee1 = new Trainee();
	trainee1.setEmpNo(626262);
	trainee1.setEmailId("John_626262");
	
	List<Trainee>tlist = new ArrayList<Trainee>();
	tlist.add(trainee1);
	booking.setTraineesList(tlist);
	ee.expect(Exception.class);
	ee.expectMessage("Validator.INVALID_ASSESSMENT_DATE");
	Validator valid=new Validator();
	valid.validate(booking);
	
}

@Test
public void isInvalidExceptionValidAssessmentType() throws Exception {
	Booking booking=new Booking();
	booking.setAssessmentDate(LocalDate.now().plusDays(4));
	booking.setAssessmentType("Obj");
	booking.setBatchName("JEE-RT1-CS");		
	booking.setCourseName("FA2");
	
	Trainee trainee1 = new Trainee();
	trainee1.setEmpNo(626262);
	trainee1.setEmailId("John_626262");
	
	List<Trainee>tlist = new ArrayList<Trainee>();
	tlist.add(trainee1);
	booking.setTraineesList(tlist);
	ee.expect(Exception.class);
	ee.expectMessage("Validator.INVALID_ASSESSMENT_TYPE");
	Validator valid=new Validator();
	valid.validate(booking);
	
	
}
@Test
public void isInvalidExceptionValidEmailId() throws Exception {
	Booking booking=new Booking();
	booking.setAssessmentDate(LocalDate.now().plusDays(4));
	booking.setAssessmentType("Objective");
	booking.setBatchName("JEE-RT1-CS");		
	booking.setCourseName("FA1");
	
	Trainee trainee1 = new Trainee();
	trainee1.setEmpNo(626262);
	trainee1.setEmailId("John_26262626");
	
	List<Trainee>tlist = new ArrayList<Trainee>();
	tlist.add(trainee1);
	booking.setTraineesList(tlist);
	ee.expect(Exception.class);
	ee.expectMessage("Validator.INVALID_EMAIL_ID");
	Validator valid=new Validator();
	valid.validate(booking);
}

	
	

}
