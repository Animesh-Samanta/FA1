package application;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

public class Validator {

	public void validate(Bike bike) throws Exception {
		if(!isValidBikeName(bike.getBikeName())) {
			throw new Exception("Validator.INVALID_BIKENAME");
		}
		if(!isValidModel(bike.getModel())){
			throw new Exception("Validator.INVALID_MODEL");
		}
		if(!isValidCompanyName(bike.getCompanyName())) {
			throw new Exception("Validator.INVALID_COMPANY_NAME");
		}
		if(!isValidBikeSoldOn(bike.getBikeSoldOn())) {
			throw new Exception("Validator.INVALID_BIKE_SOLD_ON");
		}
		if(!isValidPrice(bike.getPrice())) {
			throw new Exception("Validator.INVALID_PRICE");
		}
		if(!isValidSerialNumber(bike.getSerialNumber(),bike.getCompanyName())) {
			throw new Exception("Validator.INVALID_SERIAL_NUMBER");
		}
		
		
	}

	public boolean isValidBikeName(String bikeName) {
		String regex="[a-zA-Z0-9]+";
		if(bikeName.matches(regex)) {
			return true;
		}
		return false;
	}

	public boolean isValidModel(LocalDate model) {
		LocalDate today=LocalDate.now();
		//System.out.println("hi"+ChronoUnit.MONTHS.between(model,today));
		if(model.isBefore(today) && ChronoUnit.MONTHS.between(model,today)<5) {
			return true;
		}
		return false;
	}

	public boolean isValidCompanyName(String companyName){
		String regex="[A-Z][a-zA-Z]+";
		if(companyName.matches(regex)) {
			return true;
		}
		return false;
	}
	
	public boolean isValidBikeSoldOn(LocalDateTime bikeSoldOn){
		
		LocalDateTime today=LocalDateTime.now();
		if(today.getDayOfMonth()==bikeSoldOn.getDayOfMonth() && today.getDayOfYear()==bikeSoldOn.getDayOfYear() ) {
			return true;
		}
		return false;
	}
	
	public boolean isValidPrice(double price){
		
		if(price>=50000) {
			return true;
		}
		return false;
	}
	
	public boolean isValidSerialNumber(String serialNumber,String companyName){
		String regex="[0-9]+";
		String arr[]=serialNumber.split(":");
		if(arr.length<2 || arr.length>2) {
			return false;
		}
		else {
			String first3=companyName.substring(0, 3);
			if(first3.equals(arr[0]) && arr[1].matches(regex)) {
				return true;
			}
		}
		
		return false;
	}
}
