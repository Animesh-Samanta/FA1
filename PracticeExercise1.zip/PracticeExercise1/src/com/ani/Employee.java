package com.ani;

public class Employee {
   private String employeeName;
   private Integer noOfMatches;
   private Integer noOfGoals;
public Employee(String employeeName, Integer noOfMatches, Integer noOfGoals) {
	
	this.employeeName = employeeName;
	this.noOfMatches = noOfMatches;
	this.noOfGoals = noOfGoals;
}
public String getEmployeeName() {
	return employeeName;
}
public void setEmployeeName(String employeeName) {
	this.employeeName = employeeName;
}
public Integer getNoOfMatches() {
	return noOfMatches;
}
public void setNoOfMatches(Integer noOfMatches) {
	this.noOfMatches = noOfMatches;
}
public Integer getNoOfGoals() {
	return noOfGoals;
}
public void setNoOfGoals(Integer noOfGoals) {
	this.noOfGoals = noOfGoals;
}


   
}
