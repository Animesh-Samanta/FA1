package application;

import java.time.DayOfWeek;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import java.util.List;



public class Validator {
	
	public void validate(Booking booking) throws Exception {
		
		
		if(isValidBatchName(booking.getBatchName())) {
			
		}
		else {
			throw new Exception("Validator.INVALID_BATCH_NAME");
		}
       if(isValidCourseName(booking.getCourseName())) {
			
		}
		else {
			throw new Exception("Validator.INVALID_COURSE_NAME");
		}
       if(isValidAssessmentDate(booking.getAssessmentDate())) {
			
		}
		else {
			throw new Exception("Validator.INVALID_ASSESSMENT_DATE");
		}
       if(isValidAssessmentType(booking.getAssessmentType())) {
			
		}
		else {
			throw new Exception("Validator.INVALID_ASSESSMENT_TYPE");
		}
       
       if(isValidEmailId(booking.getTraineesList())) {
			
		}
		else {
			throw new Exception("Validator.INVALID_EMAIL_ID");
		}
       
		
		
		
		
	}
	
	public Boolean isValidBatchName(String batchName) {
		String arr[]=batchName.split("-");
		if(arr.length<3) {
			return false;
		}
		boolean b1=arr[0].equals("JEE")||arr[0].equals("MS")||arr[0].equals("IVS");
		boolean b2=arr[1].equals("RT1")||arr[1].equals("RT2");
		boolean b3=arr[2].equals("CS")||arr[2].equals("NCS");
		if(b1 && b2 && b3) 
		{
			return true;
		}
		return false;
	}

	public Boolean isValidCourseName(String courseName) {
		String regex="FA[1-9]+";
		if(courseName.matches(regex)) {
			return true;
			
		}
		return false;
	}
	
	public Boolean isValidAssessmentDate(LocalDate assessmentDate) {
		LocalDate today=LocalDate.now();
		long days=ChronoUnit.DAYS.between(today, assessmentDate);
		DayOfWeek dayOfWeek=assessmentDate.getDayOfWeek();
		if(dayOfWeek.equals(DayOfWeek.SATURDAY)||dayOfWeek.equals(DayOfWeek.SUNDAY)) {
			return false;
		}
		if(days>=7) {
			return false;
		}
		return true;
		
	}

	
	public Boolean isValidAssessmentType(String assessmentType) {
		
		if(assessmentType.equals("Objective") || assessmentType.equals("Hands-On")) {
			return true;
		}
		else {
			return false;
		}
		
		
	}

	public Boolean isValidEmailId(List<Trainee>traineesList) {
		String regex="[a-zA-Z]+";
		for(Trainee t:traineesList) {
			String arr[]=t.getEmailId().split("_");
			if((t.getEmpNo()!=Integer.parseInt(arr[1]) || !(arr[0].matches(regex)))) {
				
				return false;
			}
			
		}
		
		return true;
		
	}
	
}
