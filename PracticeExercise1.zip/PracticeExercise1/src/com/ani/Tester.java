package com.ani;

import java.util.ArrayList;
import java.util.List;

public class Tester {

	public static void main(String[] args) {
		Employee e1=new Employee("Enoch",2,1);
		Employee e2=new Employee("Hudson",3,5);
		Employee e3=new Employee("Rufs",1,1);
		Employee e4=new Employee("Derek",5,2);
		Employee e5=new Employee("Harry",3,2);
		Employee e6=new Employee("Ronald",2,3);
		List<Employee> li=new ArrayList<Employee>();
		li.add(e1);
		li.add(e2);
		li.add(e3);
		li.add(e4);
		li.add(e5);
		li.add(e6);
		List<Employee> lif=new ArrayList<Employee>();
		System.out.println("Name of employees selected for final selection round:");
		li.forEach(x->{if(x.getNoOfGoals()/x.getNoOfMatches()>=1) {
			System.out.println(x.getEmployeeName());
			lif.add(x);
		}
			
			});
		System.out.println("Total number of employee selected for final selection round: "+lif.size());
		}
		

	}


