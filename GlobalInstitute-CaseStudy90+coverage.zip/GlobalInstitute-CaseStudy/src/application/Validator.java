package application;

public class Validator {

	public void validate(Student student) throws Exception {
		
		if(!isValidStudentName(student.getStudentName())) {
			
			throw new Exception("Validator.INVALID_STUDENTNAME");
		}
		if(!isValidStudentId(student.getStudentId())) {
			throw new Exception("Validator.INVALID_STUDENTID");
		}
		if(!isValidDepartment(student.getDepartment())) {
			throw new Exception("Validator.INVALID_DEPARTMENT");
		}
		if(!isValidExamMarks(student)) {
			throw new Exception("Validator.INVALID_EXAMMARKS");
		}
		if(!isValidResult(student.getResult())) 
		{
			throw new Exception("Validator.INVALID_RESULT");
		}
		
	}

	
	public Boolean isValidStudentName(String studentName) {
		String regex="[a-zA-Z]+[A-Za-z, ]+";
		if(studentName.matches(regex)) {
			return true;
		}
		
		return false;
	}

	public Boolean isValidStudentId(Integer studentId) {
		
		if(studentId>1000 && studentId<10000) {
			return true;
		}
		return false;
	}

	
	public Boolean isValidDepartment(String department) {
		
		if(department.equals("ECE")||department.equals("CSE")||department.equals("IT"))
		{
			return true;
		}
		
		return false;
	}

	public Boolean isValidExamMarks(Student student) {
		boolean b1=
				(student.getMark1()<=100)
				&& 
				(student.getMark1()>=0);
		boolean b2=student.getMark2()<=100 && student.getMark2()>=0;
		boolean b3=student.getMark3()<=100 && student.getMark3()>=0;
		
		if(b1 && b2 && b3) {
			return true;
		}
		
		return false;
	}

	
	public Boolean isValidResult(Character result) {
		
		if(result.equals('P') || result.equals('F')) {
			return true;
		}
		
		return false;
	}
}
