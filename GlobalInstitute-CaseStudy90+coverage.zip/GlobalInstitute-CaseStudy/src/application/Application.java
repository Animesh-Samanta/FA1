package application;

import java.util.List;
import java.util.Properties;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import resources.AppConfig;
import resources.LogConfig;

public class Application {
	private Properties pro=AppConfig.PROPERTIES;
	private Logger log=LogConfig.getLogger(Application.class);
	// can have status as 'P' only if all 3 marks are 50 and above
	public String addStudent(Student student) throws Exception {
		
		Validator validator=new Validator();
		DataProvider dp=new DataProvider();
		try {
		validator.validate(student);
		
		if(student.getMark1()<50||student.getMark2()<50||student.getMark3()<50) {
			
			if(!student.getResult().equals('F')) {
			log.error(pro.getProperty("Application.INVALID_RESULT_FAIL"));
			throw new Exception("Application.INVALID_RESULT_FAIL");
			}
		}
		if(student.getMark1()>=50 && student.getMark2()>=50 && student.getMark3()>=50) {
			if(!student.getResult().equals('P')) {
				log.error(pro.getProperty("Application.INVALID_RESULT_PASS"));
				throw new Exception("Application.INVALID_RESULT_PASS");
			}
		}
		
		
		
		}
		catch (Exception e) {
			throw e;
		}
		return dp.addStudent(student);
		
	}

	public String calculateGrade(StudentReport studentReport) throws Exception {
		try {
		Character rep=studentReport.getResult();
		if(rep=='F') 
		{
			return "NA";
		}
		else {
			double avg=studentReport.getTotalMarks()/studentReport.getNoOfSubjects();
			if(avg>=90) {
				return "A+";
			}
			else if(avg>=80 && avg<90) {
				return "A";
			}
			else if(avg>=70 && avg<80) {
				return "B";
			}
			else {
				return "C";
			}
		}
		}
		catch(Exception e) {
			throw e;
		}
		
		
	}

	public List<StudentReport> getGradesForStudentsInRange(String range) throws Exception {
		
		
		try {
		DataProvider dp=new DataProvider();
		List<StudentReport> li=dp.getAllStudents();
		String arr[]=range.split("-");
		int lowerRange=Integer.parseInt(arr[0]);
		int upperRange=Integer.parseInt(arr[1]);
		
		Stream<StudentReport> liS=li.stream().filter(x->x.getTotalMarks()>=lowerRange && x.getTotalMarks()<=upperRange);
		li=liS.collect(Collectors.toList());
		
		if(li.size()==0) {
			log.error(pro.getProperty("Application.NO_RECORDS"));
			throw new Exception("Application.NO_RECORDS");
		}
		for(StudentReport sr:li) {
			sr.setGrade(calculateGrade(sr));
		}
		return li;
		}
		catch(Exception e) {
			throw e;
		}


	}
}
