package com.ani;

import java.util.ArrayList;
import java.util.List;

public class FindValley {
	
	
	public static List<String> findValley(int arr[][]) {
		int count=0;
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr.length;j++) {
				System.out.print(arr[i][j]+"  ");
			}
			System.out.println();
		}
		System.out.println("***********************");
		List<String> li=new ArrayList<String>();
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr.length;j++) {
				if(j!=0 && i!=0 && j!=arr[i].length-1 && i!=arr.length-1) {
					//System.out.print(arr[i][j]+"("+i+","+j+")");
					int currentPoint=arr[i][j];
					int point1=arr[i+1][j];
					int point2=arr[i-1][j];
					int point3=arr[i][j+1];
					int point4=arr[i][j-1];
					if(currentPoint<point1 && currentPoint<point2 && currentPoint<point3 && currentPoint<point4) {
						li.add("("+i+","+j+")");
						count++;
					}
				
				}
				
			}
			
		}
		
		
		return li;
		
		
	}

}
