package test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import application.Application;
import application.Bike;
import junit.framework.Assert;

public class ApplicationTest {
	@Rule
    public ExpectedException ee = ExpectedException.none(); 
	@Test
	public void addBikeValidDetails() throws Exception {
        Bike bike = new Bike();
		
		bike.setBikeName("Karizma");
		bike.setPrice(95000.0);
		bike.setBikeId(1227);
		bike.setBikeSoldOn(LocalDateTime.now());
		bike.setCompanyName("Herro");
		bike.setSerialNumber("Her:1256");
		LocalDate date1 = LocalDate.now().withMonth(3);
		bike.setModel(date1);
		List<Bike> list = new ArrayList<Bike>();
		list.add(bike);
		Application app = new Application();
		
		Assert.assertEquals("success", app.addBikes(list));
	 }
	@Test
	public void addBikeValidInValidBikeName() throws Exception {
        Bike bike = new Bike();
		
		bike.setBikeName("Yessdi@123");
		bike.setPrice(956000.0);
		bike.setBikeId(1228);
		bike.setBikeSoldOn(LocalDateTime.now());
		bike.setCompanyName("Java");
		bike.setSerialNumber("Jav:1256");
		LocalDate date1 = LocalDate.now().withMonth(3);
		bike.setModel(date1);
		List<Bike> list = new ArrayList<Bike>();
		list.add(bike);
		
		ee.expect(Exception.class);
		ee.expectMessage("Validator.INVALID_BIKENAME");
		Application app = new Application();
		app.addBikes(list);
	 }
	@Test 
	public void getBikeDetailsValidmodel() throws Exception{
		LocalDate model = LocalDate.of(2012,3,5);
		
		Application app = new Application();
		
		Assert.assertEquals(2, app.getBikeDetails(model).size());
	 }
	@Test
	public void getBikeDetailsInValidmodel() throws Exception{
		LocalDate model = LocalDate.of(2016,3,5);
		ee.expect(Exception.class);
		ee.expectMessage("Application.NO_RECORDS_FOUND");
		Application app = new Application();
		app.getBikeDetails(model);
	 }
}
