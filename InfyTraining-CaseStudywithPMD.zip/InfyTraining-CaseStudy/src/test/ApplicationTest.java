package test;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import application.Application;
import application.Booking;
import application.Report;
import application.Trainee;
import junit.framework.Assert;

public class ApplicationTest {
	
	
	@Rule
    public ExpectedException ee = ExpectedException.none();   
    @Test
	public void bookAssessmentInvalidBatchName()throws Exception{
		Booking booking=new Booking();
		booking.setAssessmentDate(LocalDate.now().plusDays(4));
		booking.setAssessmentType("Objective");
		booking.setBatchName("JEE-rt1-cs");		
		booking.setCourseName("FA1");
		
		Trainee trainee1 = new Trainee();
		trainee1.setEmpNo(626262);
		trainee1.setEmailId("John_626262");
		
		List<Trainee>tlist = new ArrayList<Trainee>();
		tlist.add(trainee1);
		booking.setTraineesList(tlist);
		ee.expect(Exception.class);
		ee.expectMessage("Validator.INVALID_BATCH_NAME");
		Application app=new Application();
		app.bookAssessment(booking);
		
	}
	@Test
	public void bookAssessmentInvalidEmailId()throws Exception{
		
		Booking booking=new Booking();
		booking.setAssessmentDate(LocalDate.now().plusDays(4));
		booking.setAssessmentType("Objective");
		booking.setBatchName("JEE-RT2-CS");		
		booking.setCourseName("FA1");
		
		Trainee trainee1 = new Trainee();
		trainee1.setEmpNo(626262);
		trainee1.setEmailId("John_262626");
		
		List<Trainee>tlist = new ArrayList<Trainee>();
		tlist.add(trainee1);
		booking.setTraineesList(tlist);
		ee.expect(Exception.class);
		ee.expectMessage("Validator.INVALID_EMAIL_ID");
		Application app=new Application();
		app.bookAssessment(booking);
		
	}
	@Test
	public void getAssessmentReportNotFound()throws Exception{
		ee.expect(Exception.class);
		ee.expectMessage("Application.NO_RECORDS_FOUND");
		Application app=new Application();
		app.getAssessmentReport("IVS-RT1-Cs");
	}
	@Test
	public void getAssessmentReportFound()throws Exception{
		
		Application app=new Application();
		List<Report> li=app.getAssessmentReport("JEE-RT1-NCS");
		Assert.assertTrue(li.size()>0);
		
	}
	@Test
	public void validDetailsAdded()throws Exception{
		
		Booking booking=new Booking();
		booking.setAssessmentDate(LocalDate.now().plusDays(4));
		booking.setAssessmentType("Objective");
		booking.setBatchName("JEE-RT2-CS");		
		booking.setCourseName("FA1");
		
		Trainee trainee1 = new Trainee();
		trainee1.setEmpNo(626262);
		trainee1.setEmailId("John_626262");
		
		List<Trainee>tlist = new ArrayList<Trainee>();
		tlist.add(trainee1);
		booking.setTraineesList(tlist);
		
		Application app=new Application();
		
		Assert.assertEquals(new Integer("90"), app.bookAssessment(booking));
		
	}
	
}
