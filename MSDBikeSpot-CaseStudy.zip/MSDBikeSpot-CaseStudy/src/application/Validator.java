package application;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class Validator {

	public void validate(Bike bike) throws Exception {
		// Use isValidBikeName, isValidModel, isValidCompanyName, isValidBikeSoldOn, isValidPrice, isValidSerialNumber to validate the bike details
		// For invalid inputs throw exceptions with the corresponding messages
	}

	public boolean isValidBikeName(String bikeName) {
		return true;
	}

	public boolean isValidModel(LocalDate model) {
		return true;
	}

	public boolean isValidCompanyName(String companyName){
		return true;
	}
	
	public boolean isValidBikeSoldOn(LocalDateTime bikeSoldOn){
		return true;
	}
	
	public boolean isValidPrice(double price){
		return true;
	}
	
	public boolean isValidSerialNumber(String serialNumber,String companyName){
		return true;
	}
}
