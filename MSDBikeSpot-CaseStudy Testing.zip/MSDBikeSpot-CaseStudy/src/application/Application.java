package application;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;


public class Application {

	public String addBikes(List<Bike> bikeList) throws Exception{
		try {
		Validator validate=new Validator();
		String str="";
		for(Bike bike:bikeList) {
			validate.validate(bike);
			DataProvider dp=new DataProvider();
			dp.addBikes(bike);
		}
		for(Bike bike:bikeList) {
			
			DataProvider dp=new DataProvider();
			str=dp.addBikes(bike);
		}
		return str;
		}
		catch(Exception e) {
			throw e;
		}
	}
	
	
	public Set<BikeReport> getBikeDetails(LocalDate model) throws Exception{
		DataProvider dp=new DataProvider();
		Set<Bike> bikeSet=dp.getBikeDetails();
		Set<BikeReport> br=new LinkedHashSet<BikeReport>();
		for(Bike bike:bikeSet) {
			
			if(bike.getModel().equals(model) || bike.getModel().isAfter(model)) {
				BikeReport bkr=new BikeReport();
				bkr.setBikeName(bike.getBikeName());
				bkr.setBikeSoldOn(bike.getBikeSoldOn());
				bkr.setCompanyName(bike.getCompanyName());
				bkr.setPrice(bike.getPrice());
				br.add(bkr);
			}
		}
		
		if(br.size()==0) {
			throw new Exception("Application.NO_RECORDS_FOUND");
		}
		return br;
	}
}
