package test;



import java.util.ArrayList;
import java.util.List;


import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import application.Application;
import application.Student;
import application.StudentReport;
import junit.framework.Assert;

public class ApplicationTest {
	@Rule
    public ExpectedException ee = ExpectedException.none();   
	@Test
	public void addStudentInvalidDepartment() throws Exception {
		

		Student student = new Student();
		student.setStudentId(1004);
		student.setStudentName("Jacob");
		student.setDepartment("cse");
		student.setMark1(50);
		student.setMark2(60);
		student.setMark3(65);
		student.setResult('P');
		ee.expect(Exception.class);
		ee.expectMessage("Validator.INVALID_DEPARTMENT");
		Application app = new Application();
		app.addStudent(student);
		
	}
	@Test
	public void addStudentValidDepartment() throws Exception {
		

		Student student = new Student();
		student.setStudentId(1004);
		student.setStudentName("Jacob");
		student.setDepartment("CSE");
		student.setMark1(50);
		student.setMark2(60);
		student.setMark3(65);
		student.setResult('P');
		
		Application app = new Application();
		
		Assert.assertEquals("SUCCESS", app.addStudent(student));
		
	}
	@Test
	public void addStudentInvalidMarks() throws Exception {
		

		Student student = new Student();
		student.setStudentId(1004);
		student.setStudentName("Jacob");
		student.setDepartment("CSE");
		student.setMark1(-50);
		student.setMark2(110);
		student.setMark3(65);
		student.setResult('P');
		ee.expect(Exception.class);
		ee.expectMessage("Validator.INVALID_EXAMMARKS");
		Application app = new Application();
		app.addStudent(student);
	}
    @Test
	public void addStudentInvalidStudentId() throws Exception {

		

		Student student = new Student();
		student.setStudentId(10040);
		student.setStudentName("Jacob");
		student.setDepartment("CSE");
		student.setMark1(50);
		student.setMark2(60);
		student.setMark3(65);
		student.setResult('P');
		ee.expect(Exception.class);
		ee.expectMessage("Validator.INVALID_STUDENTID");
		Application app = new Application();
		app.addStudent(student);
	}
    @Test
	public void addStudentInvalidStudentResult() throws Exception {

		

		Student student = new Student();
		student.setStudentId(1004);
		student.setStudentName("Jacob");
		student.setDepartment("CSE");
		student.setMark1(43);
		student.setMark2(60);
		student.setMark3(65);
		student.setResult('P');
		ee.expect(Exception.class);
		ee.expectMessage("Application.INVALID_RESULT_FAIL");
		Application app = new Application();
		app.addStudent(student);
	}
    
    
    @Test
	public void getGradesForStudentsInRangeInvalidNoData() throws Exception {

		
    	Application app = new Application();
		
		ee.expect(Exception.class);
		ee.expectMessage("Application.NO_RECORDS");
		List<StudentReport> li=app.getGradesForStudentsInRange("100-130");
		
	}
    @Test
	public void getGradesForStudentsInRangeData() throws Exception {

		
    	Application app = new Application();
		
		List<StudentReport> li=app.getGradesForStudentsInRange("100-300");
		Assert.assertTrue(li.size()>0);
		
	}
    
    
    
    
    
}
