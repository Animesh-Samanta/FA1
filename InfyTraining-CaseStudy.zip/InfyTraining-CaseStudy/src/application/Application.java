package application;

import java.util.List;

public class Application {
	
	public Integer bookAssessment(Booking booking) throws Exception {
		return null;
	}
	
	public Integer getDurationOfExam(String assessmentType) {
		return null;
	}
	
	public List<Report> getAssessmentReport(String batchName) throws Exception {
		return null;
	}
}
