package application;


public class Student {
	
	// Implement the class as per class diagram 
}
