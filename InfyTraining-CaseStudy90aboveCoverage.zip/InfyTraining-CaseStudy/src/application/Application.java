package application;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.logging.log4j.Logger;

import resources.LogConfig;

public class Application {
	Logger log=LogConfig.getLogger(Application.class);
	public Integer bookAssessment(Booking booking) throws Exception {
		Validator v=new Validator();
		DataProvider d=new DataProvider();
		try {
		v.validate(booking);
		booking.setDurationInMin(getDurationOfExam(booking.getAssessmentType()));
		;
		return d.bookAssessment(booking);
		}
		catch(Exception e) {
			throw e;
		}
		
	}
	
	public Integer getDurationOfExam(String assessmentType) {
		DataProvider d=new DataProvider();
		Map<String,Integer> m=d.getExamDuration();
		return m.get(assessmentType);
		 
	}
	
	public List<Report> getAssessmentReport(String batchName) throws Exception {
		try {
		DataProvider d=new DataProvider();
		List<Report> rep=d.getAssessmentReport();
		
		Stream<Report> repStr=rep.stream().filter(x->x.getBatchName().equals(batchName) && x.getAssessmentDate().isAfter(LocalDate.now()));
		rep=repStr.collect(Collectors.toList());
		
		if(rep.size()==0) {
			log.error("Application.NO_RECORDS_FOUND");
			throw new Exception("Application.NO_RECORDS_FOUND");
		}
		return rep;
		}
		catch(Exception e) {
			throw e;
		}
	}
}
