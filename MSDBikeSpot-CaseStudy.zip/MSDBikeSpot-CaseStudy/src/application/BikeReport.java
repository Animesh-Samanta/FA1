package application;

public class BikeReport {
	
	// Implement the class as per class diagram 
}
