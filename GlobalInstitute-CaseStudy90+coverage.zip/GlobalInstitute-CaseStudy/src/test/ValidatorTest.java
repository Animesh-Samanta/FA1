package test;

import org.junit.Assert;
import org.junit.Test;

import application.Student;
import application.Validator;

public class ValidatorTest {
	
	
	
	@Test
	public void isValidStudentName() {
		Validator valid=new Validator();
		Assert.assertTrue(valid.isValidStudentName("Vignesh"));
		Assert.assertFalse(valid.isValidStudentName("Vignesh9"));
		
	}
	@Test
	public void isValidStudentId() {
		Validator valid=new Validator();
		Assert.assertTrue(valid.isValidStudentId(1001));
		Assert.assertFalse(valid.isValidStudentId(100));
	}

	@Test
	public void isValidDepartment() {
		Validator valid=new Validator();
		Assert.assertTrue(valid.isValidDepartment("ECE"));
		Assert.assertFalse(valid.isValidDepartment("ECEE"));
		
	}
	@Test
	public void isValidExamMarks() {
		Validator valid=new Validator();
		Student student = new Student();
		student.setStudentId(1001);
		student.setStudentName("Vignesh");
		student.setDepartment("ECE");
		student.setMark1(70);
		student.setMark2(44);
		student.setMark3(60);
		student.setResult('P');
		Assert.assertTrue(valid.isValidExamMarks(student));
		student.setStudentId(1001);
		student.setStudentName("Vignesh");
		student.setDepartment("ECE");
		student.setMark1(-70);
		student.setMark2(44);
		student.setMark3(60);
		student.setResult('P');
		Assert.assertFalse(valid.isValidExamMarks(student));
	}

	@Test
	public void isValidResult() {
		Validator valid=new Validator();
		Assert.assertTrue(valid.isValidResult('P'));
		Assert.assertTrue(valid.isValidResult('F'));
		Assert.assertFalse(valid.isValidResult('f'));
		
	}

}
