package com.ani;

import java.util.List;

public class Tester {

	public static void main(String[] args) {
		int arr [] [] = {{1,2,4,5,4,6},{4,0,3,6,0,4},{2,6,3,2,3,5},{3,4,6,3,6,3},{1,1,1,1,2,1},{1,1,1,1,1,1}};
		List<String> li=FindValley.findValley(arr);
		if(li.size()==0) {
			System.out.println("No Valley found");
		}
		else {
			System.out.println("Valleys Found at cordinates");
		System.out.println(li);
		}

	}

}
